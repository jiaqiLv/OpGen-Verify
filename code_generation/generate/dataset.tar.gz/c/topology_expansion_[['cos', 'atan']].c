void default_function_kernel(float* compute, float* compute_1, float* ph_0) {
  #pragma omp parallel for
  for (int32_t i0 = 0; i0 < 7; ++i0) {
    for (int32_t i1 = 0; i1 < 3; ++i1) {
      for (int32_t i2 = 0; i2 < 8; ++i2) {
        compute[(((i0 * 24) + (i1 * 8)) + i2)] = cosf(ph_0[(((i0 * 24) + (i1 * 8)) + i2)]);
      }
    }
  }
  #pragma omp parallel for
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 21; ++i0_i1_fused) {
    for (int32_t i2_1 = 0; i2_1 < 8; ++i2_1) {
      compute_1[((i0_i1_fused * 8) + i2_1)] = atanf(ph_0[((i0_i1_fused * 8) + i2_1)]);
    }
  }
}

