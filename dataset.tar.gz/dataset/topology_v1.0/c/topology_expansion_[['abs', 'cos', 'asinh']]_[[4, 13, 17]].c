void default_function_kernel(float* compute, float* compute_1, float* ph_0) {
  #pragma omp parallel for
  for (int32_t i0 = 0; i0 < 4; ++i0) {
    for (int32_t i1 = 0; i1 < 13; ++i1) {
      for (int32_t i2 = 0; i2 < 17; ++i2) {
        compute[(((i0 * 221) + (i1 * 17)) + i2)] = fabsf(ph_0[(((i0 * 221) + (i1 * 17)) + i2)]);
      }
    }
  }
  #pragma omp parallel for
  for (int32_t i0_i1_fused = 0; i0_i1_fused < 52; ++i0_i1_fused) {
    for (int32_t i2_1 = 0; i2_1 < 17; ++i2_1) {
      compute_1[((i0_i1_fused * 17) + i2_1)] = asinhf(cosf(ph_0[((i0_i1_fused * 17) + i2_1)]));
    }
  }
}

